-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/adlsracingf1/presentation"

-- COMMAND ----------

DESC DATABASE f1_presentation;

-- COMMAND ----------

desc database f1_raw

-- COMMAND ----------

